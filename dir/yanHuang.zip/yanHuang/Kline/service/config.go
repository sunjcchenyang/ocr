package service

// 配置文件模块

import (
	"io/ioutil"
	"log"

	"go.uber.org/zap"

	"github.com/naoina/toml"
	"github.com/naoina/toml/ast"
)

// CommonConfig Common
type CommonConfig struct {
	Version  string
	IsDebug  bool
	LogLevel string
	LogPath  string
}

// ServerConf echo config struct
type ServerConf struct {
	Addr string
}

//MgDBConf mgdb config struct
type MgDBConf struct {
	Addr       string
	Name       string //表名
	Collection string //集合名称
}

//sunjc add
type LineConf struct {
	MinRange float64
	MaxRange float64
	Flag     int
}

// Config ...
type Config struct {
	Common  *CommonConfig
	ServerC *ServerConf
	MgC     *MgDBConf
	LineCf  *LineConf
}

// Conf ...
var Conf = &Config{}

// LoadConfig ...
func LoadConfig() {
	// init the new config params
	initConf()

	contents, err := ioutil.ReadFile("kline.toml")
	if err != nil {
		log.Fatal("[FATAL] load kline.toml: ", err)
	}
	tbl, err := toml.Parse(contents)
	if err != nil {
		log.Fatal("[FATAL] parse kline.toml: ", err)
	}
	// parse common config
	parseCommon(tbl)
	// init log
	InitLogger()

	// parse Echo config
	parseServer(tbl)

	//parse mgdb config
	parseMogd(tbl)
	//prase line config
	parseLine(tbl)

	Logger.Info("LoadConfig", zap.Any("Config", Conf))
}

func initConf() {
	Conf = &Config{
		Common:  &CommonConfig{},
		ServerC: &ServerConf{},
		MgC:     &MgDBConf{},
		LineCf:  &LineConf{},
	}
}

func parseCommon(tbl *ast.Table) {
	if val, ok := tbl.Fields["common"]; ok {
		subTbl, ok := val.(*ast.Table)
		if !ok {
			log.Fatalln("[FATAL] : ", subTbl)
		}

		err := toml.UnmarshalTable(subTbl, Conf.Common)
		if err != nil {
			log.Fatalln("[FATAL] parseCommon: ", err, subTbl)
		}
	}
}

func parseServer(tbl *ast.Table) {
	if val, ok := tbl.Fields["server"]; ok {
		subTbl, ok := val.(*ast.Table)
		if !ok {
			log.Fatalln("[FATAL] : ", subTbl)
		}

		err := toml.UnmarshalTable(subTbl, Conf.ServerC)
		if err != nil {
			log.Fatalln("[FATAL] parseServer: ", err, subTbl)
		}
	}
}

func parseLine(tbl *ast.Table) {
	if val, ok := tbl.Fields["line"]; ok {
		subTbl, ok := val.(*ast.Table)
		if !ok {
			log.Fatalln("[FATAL] : ", subTbl)
		}

		err := toml.UnmarshalTable(subTbl, Conf.LineCf)
		if err != nil {
			log.Fatalln("[FATAL] parseServer: ", err, subTbl)
		}
	}
}

func parseMogd(tbl *ast.Table) {
	if val, ok := tbl.Fields["mgdb"]; ok {
		subTbl, ok := val.(*ast.Table)
		if !ok {
			log.Fatalln("[FATAL] : ", subTbl)
		}

		err := toml.UnmarshalTable(subTbl, Conf.MgC)
		if err != nil {
			log.Fatalln("[FATAL] parseServer: ", err, subTbl)
		}
	}
}
