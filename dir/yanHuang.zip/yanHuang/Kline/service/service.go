package service

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"math"
	"net/http"
	"strconv"
	"sync"

	"github.com/labstack/echo"
	"go.uber.org/zap"
	mgo "gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

const (
	layout = "2006-01-02 15:04:05"
	msg    = "param is error"
)

//Service service for the service struct
type Service struct {
	Address string
	MgDb    *mgo.Session
	Action  map[string]string
	sync.RWMutex
}

//Kline Kline the client struct
type Kline struct {
	OpenPrice    string      `bson:"openPrice"`
	HighestPrice string      `bson:"highestPrice"`
	LowestPrice  string      `bson:"lowestPrice"`
	ClosePrice   string      `bson:"closePrice"`
	Time         interface{} `bson:"time"`
	Period       string      `bson:"period"`
	Count        string      `bson:"count"`
	Volume       string      `bson:"volume"`
	Turnover     string      `bson:"turnover"`
}

type RSP struct {
	Code   int         `json:"code"`
	Result interface{} `json:"result"`
}
type TradInfo struct {
	Amount    float64 `json:"amount"`
	Ts        int64   `json:"ts"`
	Id        float64 `json:"id"`
	Price     float64 `json:"price"`
	Direction string  `json:"direction"`
}
type TickStruct struct {
	Id        int64      `json:"id"`
	Ts        int64      `json:"ts"`
	DataArray []TradInfo `json:"data"`
}
type XmrResponse struct {
	Status string      `json:"status"`
	Ch     string      `json:"ch"`
	Ts     int64       `json:"ts"`
	Tick   *TickStruct `json:"tick"`
}

//当天24小时的交易数据信息
type TicksDetail struct {
	Amount float64 `json:"amount"`
	Open   float64 `json:"open"`
	Close  float64 `json:"close"`
	High   float64 `json:"high"`
	Ts     int64   `json:"ts"`
	Id     int64   `json:"id"`
	Count  float64 `json:"count"`
	Low    float64 `json:"low"`
	Vol    float64 `json:"vol"`
}
type DetailInfo struct {
	Status string       `json:"status"`
	Ch     string       `json:"ch"`
	Ts     int64        `json:"ts"`
	Ticks  *TicksDetail `json:"tick"`
}

var gDetailInfo DetailInfo
var gService *Service

//Resp to client
type Resp struct {
	Code   int     `json:"code"`
	Result []Kline `json:"result"`
	Msg    string  `json:"msg"`
}

//NewService init the Service struct
func NewService() *Service {
	service := new(Service)
	service.Address = Conf.ServerC.Addr
	service.Action = make(map[string]string)
	service.MgDb = Newmgo()
	return service
}

//Start start the kline service
func (ser *Service) Start() {
	gService = ser
	//action and table
	go mapped(ser)

	//start the web service
	go Server(ser)
}

//Close close the kline service
func (ser *Service) Close() {
	ser.MgDb.Close()
}

func mapped(ser *Service) error {
	var key, value []string
	key = []string{"1min",
		"5min",
		"10min",
		"15min",
		"30min",
		"1h", "1d"}
	value = []string{
		"exchange_kline_AKB/USDT_1min",
		"exchange_kline_AKB/USDT_5min",
		"exchange_kline_AKB/USDT_10min",
		"exchange_kline_AKB/USDT_15min",
		"exchange_kline_AKB/USDT_30min",
		"exchange_kline_AKB/USDT_1hour",
		"exchange_kline_AKB/USDT_1day",
	}
	ser.Lock()
	for i := 0; i < 7; i++ {
		ser.Action[key[i]] = value[i]
	}
	ser.Unlock()
	return nil
}

//Server the server is to do web work
func Server(service *Service) error {
	irs := echo.New()
	irs.GET("/kline", handler)
	//add 接口
	irs.GET("/akbusdt", getAbkHandler)
	irs.Start(service.Address)
	return nil
}

//tests
func getAbkHandler(ctx echo.Context) error {
	//获取24小时交易的最大和最下数据
	var requestFlag = false
	if Conf.LineCf.Flag != 1 {
		resp, _err := http.Get("https://api.huobi.pro/market/detail?symbol=xmrusdt")
		if _err != nil {
			Logger.Info("getAkbHandler", zap.Any("====>", "get hight and low price error"))
			requestFlag = true
		}
		buffer, _ := ioutil.ReadAll(resp.Body)
		json.Unmarshal(buffer, &gDetailInfo)
		Logger.Info("getAkbHandler", zap.Any("gDetailInfo", gDetailInfo))
	}
	respons, err := http.Get("https://api.huobi.pro/market/trade?symbol=xmrusdt")
	if err != nil {
		//panic(err)
		Logger.Info("getAkbHandler", zap.Any("reuqestinfo", "request error"))
		return nil
	}
	r, _ := ioutil.ReadAll(respons.Body)
	var tmpxmrResponse XmrResponse
	err = json.Unmarshal(r, &tmpxmrResponse)
	tmpxmrResponse.Ch = "market.abkusdt.trade.detail"
	lens := len(tmpxmrResponse.Tick.DataArray)
	i := 0
	Logger.Info("getAkbHandler", zap.Any("====>", lens))
	for i = 0; i <= lens-1; i++ {
		if Conf.LineCf.Flag == 1 {
			prices := tmpxmrResponse.Tick.DataArray[i].Price
			mods := math.Mod(prices, 10)/10*100 + Conf.LineCf.MinRange
			value, _ := strconv.ParseFloat(fmt.Sprintf("%.4f", mods), 64)
			tmpxmrResponse.Tick.DataArray[i].Price = value
		} else {
			if requestFlag == true {
				prices := tmpxmrResponse.Tick.DataArray[i].Price
				mods := math.Mod(prices, 10)/10*100 + Conf.LineCf.MinRange
				value, _ := strconv.ParseFloat(fmt.Sprintf("%.4f", mods), 64)
				tmpxmrResponse.Tick.DataArray[i].Price = value
			} else {
				begin := Conf.LineCf.MinRange
				end := Conf.LineCf.MaxRange
				xPoint := tmpxmrResponse.Tick.DataArray[i].Price

				xmrHigh := gDetailInfo.Ticks.High
				xmrLow := gDetailInfo.Ticks.Low
				absValue := math.Abs(xPoint - xmrLow)
				yPoint := begin + (float64)(absValue/(xmrHigh-xmrLow))*(end-begin)
				Logger.Info("getAkbHandler", zap.Any("====>", xmrHigh))
				Logger.Info("getAkbHandler", zap.Any("====>", xmrLow))
				Logger.Info("getAkbHandler", zap.Any("====>", xPoint))
				value, _ := strconv.ParseFloat(fmt.Sprintf("%.4f", yPoint), 64)
				tmpxmrResponse.Tick.DataArray[i].Price = value
			}
		}

		Logger.Info("getAkbHandler", zap.Any("====>", tmpxmrResponse))
	}
	Logger.Info("getAkbHandler", zap.Any("XmrResponse", tmpxmrResponse))
	if err != nil {
		//panic(err)
		return nil
	}
	ctx.JSON(http.StatusOK, &tmpxmrResponse)
	return nil
}

func handler(ctx echo.Context) error {
	err := getData(gService, ctx)
	if err != nil {
		Logger.Error("[getData]", zap.String("@getData", err.Error()))
		if err.Error() == msg {
			ctx.JSON(http.StatusOK, &Resp{
				Code:   http.StatusBadRequest,
				Result: []Kline{},
				Msg:    "param error",
			})
			return nil
		} else {
			ctx.JSON(http.StatusOK, &Resp{
				Code:   http.StatusBadRequest,
				Result: []Kline{},
				Msg:    "service error",
			})
			return nil
		}
	}
	return nil
}

//https://api.huobi.pro/market/trade?symbol=xmrusdt

func getData(ser *Service, ctx echo.Context) error {
	var Res []Kline
	action := ctx.FormValue("auction")
	if action == "" {
		Logger.Error("[getData]", zap.String("@getData", "action is null"))
		return errors.New("param is error")
	}
	start := ctx.FormValue("startTime")
	if start == "" {
		Logger.Error("[getData]", zap.String("@getData", "start is null"))
		return errors.New("param is error")
	}
	end := ctx.FormValue("endTime")
	if end == "" {
		Logger.Error("[getData]", zap.String("@getData", "end is null"))
		return errors.New("param is error")
	}
	act, ok := ser.Action[action]
	if !ok {
		Logger.Error("getData", zap.String("@ser.Action", "action do not exist"))
		return errors.New("param is error")
	}
	Logger.Info("[msg]", zap.String("action", action), zap.String("start", start), zap.String("end", end))
	stt, err := strconv.Atoi(start)
	if err != nil {
		Logger.Error("[time.Parse]", zap.String("@time.parse", err.Error()))
		return err
	}
	edt, err := strconv.Atoi(end)
	if err != nil {
		Logger.Error("[time.Parse]", zap.String("@time.parse", err.Error()))
		return err
	}
	session := ser.MgDb.Copy()
	defer session.Close()
	collection := session.DB(Conf.MgC.Collection).C(act)
	if collection == nil {
		ctx.JSON(http.StatusBadRequest, &Resp{
			Code: http.StatusOK,
			Msg:  "mongodb 连接失败",
		})
		Logger.Error("[Mongodb Connect]", zap.String("@mongodb connect", "connect error"))
		return errors.New("mongodb 连接失败")
	}
	err = collection.Find(bson.M{"time": bson.M{"$gte": stt, "$lte": edt}}).All(&Res)
	if err != nil {
		Logger.Error("[collection.Find]", zap.String("@collection.Find", err.Error()))
		return err
	}

	if len(Res) == 0 {
		nullMap := []Kline{}
		ctx.JSON(http.StatusOK, &Resp{
			Code:   http.StatusOK,
			Result: nullMap,
			Msg:    "ok"})
		return nil
	}

	ctx.JSON(http.StatusOK, &Resp{
		Code:   http.StatusOK,
		Result: Res,
		Msg:    "ok"})

	Logger.Info("[Response]", zap.String("@Response", "response success"))
	return nil
}
